package com.ade.cityville;

import android.annotation.SuppressLint;

@SuppressLint("Instantiatable") public interface AsyncTaskCompleteListener<T> {
	public void onTaskComplete(T result);
	
	
}

