package snippet;

public class Snippet {
	
}

